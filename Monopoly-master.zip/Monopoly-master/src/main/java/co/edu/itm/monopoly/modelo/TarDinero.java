package co.edu.itm.monopoly.modelo;

/**
 * @author alejandro
 * @version 1.0
 * @created 05-oct.-2014 6:18:37 p. m.
 */
public class TarDinero implements ITarjeta {

	private int cantidadDinero;
	private String tipo;

	public TarDinero(){

	}

	public void finalize() throws Throwable {

	}

}