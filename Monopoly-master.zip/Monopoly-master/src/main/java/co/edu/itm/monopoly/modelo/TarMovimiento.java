package co.edu.itm.monopoly.modelo;

/**
 * @author alejandro
 * @version 1.0
 * @created 05-oct.-2014 6:18:58 p. m.
 */
public class TarMovimiento implements ITarjeta {

	private int cantidadPasos;
	private String tipo;

	public TarMovimiento(){

	}

	public void finalize() throws Throwable {

	}

}