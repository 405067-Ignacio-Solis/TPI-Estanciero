package co.edu.itm.monopoly.modelo;

/**
 * @author alejandro
 * @version 1.0
 * @created 05-oct.-2014 6:21:51 p. m.
 */
public class Banco {

	private long dinero;
	private Patrimonio patrimonios;
	private Jugador usuarios [];

	public Banco(){

	}


	public Banco(int cantidadUsuario){

	}

	public int pagarSalida(){
		return 200;
	}

}