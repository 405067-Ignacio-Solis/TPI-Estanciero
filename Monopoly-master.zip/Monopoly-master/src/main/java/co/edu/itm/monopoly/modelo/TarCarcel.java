package co.edu.itm.monopoly.modelo;

/**
 * @author alejandro
 * @version 1.0
 * @created 05-oct.-2014 6:19:37 p. m.
 */
public class TarCarcel implements ITarjeta {

	private int SalirEntrar;

	public TarCarcel(){

	}

	public void finalize() throws Throwable {

	}

}